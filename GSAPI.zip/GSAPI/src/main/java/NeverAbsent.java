
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.docs.v1.model.*;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.api.services.docs.v1.Docs;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;


import java.io.*;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NeverAbsent {
        private static final String APPLICATION_NAME = "Never Absent";
        private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
        private static final String TOKENS_DIRECTORY_PATH = "tokens";

        /**
         * Global instance of the scopes required by this quickstart.
         * If modifying these scopes, delete your previously saved tokens/ folder.
         */
        private static final List<String> SCOPES = Collections.singletonList("https://www.googleapis.com/auth/drive");
        private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

        /**
         * Creates an authorized Credential object.
         *
         * @param HTTP_TRANSPORT The network HTTP Transport.
         * @return An authorized Credential object.
         * @throws IOException If the credentials.json file cannot be found.
         */
        private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
            // Load client secrets.
            InputStream in = NeverAbsent.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
            if (in == null) {
                throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
            }
            GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

            // Build flow and trigger user authorization request.
            GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                    HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
                    .setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
                    .setAccessType("offline")
                    .build();
            LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
            return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
        }

        /**
         * Prints the names and majors of students in a sample spreadsheet:
         * https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
         */
        public static void main(String... args) throws IOException, GeneralSecurityException {
            // Build a new authorized API client service.
            final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
            final String spreadsheetId = "12lMQEoegIYACuJeyTgmt3Blp0IvMV88pXTgsglmz4EU";
            final String range = "Sheet1!A2:D23";
            Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
                    .setApplicationName(APPLICATION_NAME)
                    .build();
            ValueRange response = service.spreadsheets().values()
                    .get(spreadsheetId, range)
                    .execute();
            List<List<Object>> values = response.getValues();
            ArrayList<String[][]> rep = new ArrayList<String[][]>();
            if (values == null || values.isEmpty()) {
                System.out.println("No data found.");
            } else {
                int index = 0;
                for (int i = 0; i < values.size(); i++) {
                    List<Object> row = values.get(i);
                    String fN = "" + row.get(0);
                    String lN = "" + row.get(1);
                    if (Integer.parseInt("" + row.get(3)) % 5 == 0) {
                        if(rep.size()==0) {
                           String entry = fN + " " + lN + " has missed " + row.get(2) + " " + row.get(3) + " times.\n";
                            String[][] en = new String[1][3];
                            en[0][0] = fN;
                            en[0][1] = lN;
                            en[0][2] = entry;
                            rep.add(en);
                            }
                        else{
                            if(rep.get(index)[0][0].equals(fN) && rep.get(index)[0][1].equals(lN)) {
                                rep.get(index)[0][2]+= fN + " has also missed " + row.get(2) + " " + row.get(3) + " times.\n";
                            }
                             else {
                                String entry = fN + " " + lN + " has missed " + row.get(2) + " " + row.get(3) + " times.\n";
                                String[][] en = new String[1][3];
                                en[0][0] = fN;
                                en[0][1] = lN;
                                en[0][2] = entry;
                                rep.add(en);
                                 index++;
                            }
                            }
                        }

                    }
               for (String[][] item : rep) {
                    Docs Dservice = new Docs.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
                            .setApplicationName(APPLICATION_NAME)
                            .build();
                    makeDoc(Dservice, item[0][0] + " " + item[0][1] + "'s Absence Report", item);
                }
               }
        }
        private static void makeDoc(Docs service, String DocName, String[][] item) throws
                IOException, GeneralSecurityException {
            String copyTitle = DocName;
            String documentId = "1SgE19eCCzpvXMfSAMsRGouefyeqX_RBnKcfo0104CDY";
            File copyMetadata = new File().setName(copyTitle);
            final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
            Drive driveService = new Drive.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
                    .setApplicationName(APPLICATION_NAME)
                    .build();
            File documentCopyFile =
                    driveService.files().copy(documentId, copyMetadata).execute();
            String documentCopyId = documentCopyFile.getId();
            List<Request> requests = new ArrayList<>();
            requests.add(new Request()
                    .setReplaceAllText(new ReplaceAllTextRequest()
                            .setContainsText(new SubstringMatchCriteria()
                                    .setText("{FNAME}")
                                    .setMatchCase(true))
                            .setReplaceText(item[0][0])));
            requests.add(new Request()
                    .setReplaceAllText(new ReplaceAllTextRequest()
                            .setContainsText(new SubstringMatchCriteria()
                                    .setText("{LNAME}")
                                    .setMatchCase(true))
                            .setReplaceText(item[0][1])));
            requests.add(new Request()
                    .setReplaceAllText(new ReplaceAllTextRequest()
                            .setContainsText(new SubstringMatchCriteria()
                                    .setText("{REPORT}")
                                    .setMatchCase(true))
                            .setReplaceText(item[0][2])));
            requests.add(new Request()
                    .setReplaceAllText(new ReplaceAllTextRequest()
                            .setContainsText(new SubstringMatchCriteria()
                                    .setText("{DATE}")
                                    .setMatchCase(true))
                            .setReplaceText("" + java.time.LocalDate.now())));
            BatchUpdateDocumentRequest body = new BatchUpdateDocumentRequest();
            service.documents().batchUpdate(documentCopyId, body.setRequests(requests)).execute();

        }

    }